package com.mycompany.proyectocelular.modelo;

import java.io.File;

/**
 *
 * @author ASUS
 */

public class Tienda {
    private static final int TAM_NOMBRE = 20;
    private static final int TAM_REGISTRO = 26;
    
    
    private int nit;
    private String nombre;
    private String estado;
    private double calificacion;
    private boolean certificada;

    public Tienda(int nit, String nombre, String estado, double calificacion, boolean certificada) {
        this.nit = nit;
        this.nombre = nombre;
        this.estado = estado;
        this.calificacion = calificacion;
        this.certificada = certificada;
    }

    public static int getTAM_NOMBRE() {
        return TAM_NOMBRE;
    }

    public static int getTAM_REGISTRO() {
        return TAM_REGISTRO;
    }

    public int getNit() {
        return nit;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEstado() {
        return estado;
    }

    public double getCalificacion() {
        return calificacion;
    }

    public boolean isCertificada() {
        return certificada;
    }

    public void setNit(int nit) {
        this.nit = nit;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }

    public void setCertificada(boolean certificada) {
        this.certificada = certificada;
    }

        
    
    
    
   
    }

    

    

