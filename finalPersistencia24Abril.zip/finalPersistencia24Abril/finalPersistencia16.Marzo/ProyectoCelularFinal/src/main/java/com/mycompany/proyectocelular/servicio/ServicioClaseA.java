/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocelular.servicio;

import com.mycompany.proyectocelular.data.DatabaseConnection;
import com.mycompany.proyectocelular.gui.GUIPrincipal;
import com.mycompany.proyectocelular.modelo.ClaseA;
import com.mycompany.proyectocelular.modelo.Tienda;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author David Mahecha
 */
public class ServicioClaseA 
{
    
    public static boolean grabarCelular(ClaseA cel) {
        if (ServicioTienda.buscarTienda(cel.getNit()) == null) return false;
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                Statement stmt = conn.createStatement();
                String sql = "INSERT INTO CELULAR VALUES(" + cel.getImei() + ",'" 
                    + cel.getModelo() + "'," + cel.getPrecio() + "," 
                    + (cel.getTiene5G() ? 1 : 0) + ",'" + cel.getEstado() + "'," + cel.getNit() + ")";
                stmt.executeUpdate(sql);
                conn.close();
                return true;
            }
        } catch (Exception ex) { System.out.println("Error: " + ex); }
        return false;
    }
       public static List<ClaseA> getCelulares() {
        List<ClaseA> lista = new ArrayList();
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM CELULAR");
                while (rs.next()) {
                    lista.add(new ClaseA(
                        rs.getInt("IMEI"), rs.getString("MODELO"), rs.getDouble("PRECIO"),
                        rs.getInt("TIENE5G") == 1, rs.getString("ESTADO"), rs.getInt("NIT")
                    ));
                }
                conn.close();
            }
        } catch (Exception ex) { System.out.println("Error: " + ex); }
        return lista;
    }
       
    public static boolean eliminarCelular(int imeiEliminar) {
    ClaseA cel = buscarCelular(imeiEliminar);
    if (cel == null) return false;
    cel.setEstado("Inactivo");
    return actualizarCelular(cel);
}
    
    public static boolean actualizarCelular(ClaseA cel) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                Statement stmt = conn.createStatement();
                String sql = "UPDATE CELULAR SET MODELO='" + cel.getModelo() + "', PRECIO=" 
                    + cel.getPrecio() + " WHERE IMEI=" + cel.getImei();
                stmt.executeUpdate(sql);
                conn.close();
                return true;
            }
        } catch (Exception ex) { System.out.println("Error: " + ex); }
        return false;
    }
    
    public static ClaseA buscarCelular(int imeiBuscar) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            if (conn != null) {
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT * FROM CELULAR WHERE IMEI=" + imeiBuscar);
                if (rs.next()) {
                    ClaseA c = new ClaseA(rs.getInt("IMEI"), rs.getString("MODELO"),
                        rs.getDouble("PRECIO"), rs.getInt("TIENE5G") == 1,
                        rs.getString("ESTADO"), rs.getInt("NIT"));
                    conn.close();
                    return c;
                }
                conn.close();
            }
        } catch (Exception ex) { System.out.println("Error: " + ex); }
        return null;
    }
    
    public static double sumaPrecios() {
        double suma = 0;
        List<ClaseA> lista = getCelulares();
        for (ClaseA c : lista) { suma += c.getPrecio(); }
        return suma;
    }
}
