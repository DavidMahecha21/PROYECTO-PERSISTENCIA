/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectocelular.servicio;

import com.mycompany.proyectocelular.data.DatabaseConnection;
import com.mycompany.proyectocelular.gui.GUIPrincipal;
import com.mycompany.proyectocelular.modelo.Tienda;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author David Mahecha
 */
public class ServicioTienda 
{
    
    public static boolean grabarTienda(Tienda tel) {
    try {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO TIENDA VALUES(" + tel.getNit() + ",'" 
                + tel.getNombre() + "','" + tel.getEstado() + "'," 
                + tel.getCalificacion() + "," + (tel.isCertificada() ? 1 : 0) + ")";
            stmt.executeUpdate(sql);
            conn.close();
            return true;
        }
    } catch (Exception ex) { System.out.println("Error: " + ex); }
    return false;
}
    public static List<Tienda> getTiendas() {
    List<Tienda> tiendas = new ArrayList();
    try {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM TIENDA");
            while (rs.next()) {
                tiendas.add(new Tienda(
                    rs.getInt("NIT"), rs.getString("NOMBRE"), rs.getString("ESTADO"),
                    rs.getDouble("CALIFICACION"), rs.getInt("CERTIFICADA") == 1
                ));
            }
            conn.close();
        }
    } catch (Exception ex) { System.out.println("Error: " + ex); }
    return tiendas;
}
       
       
    public static boolean eliminarTienda(int nitEliminar) {
    try {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("UPDATE TIENDA SET ESTADO='Inactivo' WHERE NIT=" + nitEliminar);
            conn.close();
            return true;
        }
    } catch (Exception ex) { ex.printStackTrace(); }
    return false;
}
    
    public static boolean actualizarTienda(Tienda t) {
    try {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            Statement stmt = conn.createStatement();
            String sql = "UPDATE TIENDA SET NOMBRE='" + t.getNombre() + "', CALIFICACION=" 
                + t.getCalificacion() + " WHERE NIT=" + t.getNit();
            stmt.executeUpdate(sql);
            conn.close();
            return true;
        }
    } catch (Exception ex) { System.out.println("Error: " + ex); }
    return false;
}
    public static Tienda buscarTienda(int nitBuscar) {
    try {
        Connection conn = DatabaseConnection.getConnection();
        if (conn != null) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM TIENDA WHERE NIT=" + nitBuscar);
            if (rs.next()) {
                Tienda t = new Tienda(rs.getInt("NIT"), rs.getString("NOMBRE"),
                    rs.getString("ESTADO"), rs.getDouble("CALIFICACION"),
                    rs.getInt("CERTIFICADA") == 1);
                conn.close();
                return t;
            }
            conn.close();
        }
    } catch (Exception ex) { System.out.println("Error: " + ex); }
    return null;
}
}
