import oracledb
from pymongo import MongoClient

# ==========================================
# CONEXIÓN A ORACLE
# ==========================================
print("Conectando a Oracle...")
conexion_oracle = oracledb.connect(
    user="PER2026",
    password="PER2026",
    dsn="localhost/XEPDB1"
)
cursor_oracle = conexion_oracle.cursor()
print("✓ Conectado a Oracle")

# ==========================================
# CONEXIÓN A MONGODB
# ==========================================
print("Conectando a MongoDB...")
cliente_mongo = MongoClient("mongodb://localhost:27017/")
db_mongo = cliente_mongo["tienda_celulares"]
print("✓ Conectado a MongoDB")

# ==========================================
# LIMPIAR COLECCIONES ANTERIORES
# ==========================================
db_mongo["coleccion_celulares"].drop()
db_mongo["coleccion_clientes"].drop()
db_mongo["coleccion_ventas"].drop()
print("✓ Colecciones limpiadas")

# ==========================================
# MIGRAR CELULARES
# ==========================================
print("\nMigrando CELULARES...")
cursor_oracle.execute("SELECT ID, NOMBRE, MODELO, PRECIO, COLOR, ESTADO FROM CELULAR")
celulares = cursor_oracle.fetchall()

coleccion_celulares = db_mongo["coleccion_celulares"]
for c in celulares:
    documento = {
        "id_celular": c[0],
        "nombre": c[1],
        "modelo": c[2],
        "precio": c[3],
        "color": c[4],
        "estado": c[5]
    }
    coleccion_celulares.insert_one(documento)
print(f"✓ {len(celulares)} celulares migrados")

# ==========================================
# MIGRAR CLIENTES
# ==========================================
print("Migrando CLIENTES...")
cursor_oracle.execute("SELECT ID, NUMDOC, TIPODOC, NOMBRE, TELEFONO, EMAIL, ESTADO FROM CLIENTE")
clientes = cursor_oracle.fetchall()

coleccion_clientes = db_mongo["coleccion_clientes"]
for c in clientes:
    documento = {
        "id_cliente": c[0],
        "numdoc": c[1],
        "tipodoc": c[2],
        "nombre": c[3],
        "telefono": c[4],
        "email": c[5],
        "estado": c[6]
    }
    coleccion_clientes.insert_one(documento)
print(f"✓ {len(clientes)} clientes migrados")

# ==========================================
# MIGRAR VENTAS CON DETALLE ADENTRO
# ==========================================
print("Migrando VENTAS con DETVENTA...")
cursor_oracle.execute("SELECT ID, FECHA, TOTAL, CLIENTEID FROM VENTA")
ventas = cursor_oracle.fetchall()

coleccion_ventas = db_mongo["coleccion_ventas"]
for v in ventas:
    id_venta = v[0]
    cursor_oracle.execute(
        "SELECT ID, CANTIDAD, PRECIOTOTAL, CELULARID FROM DETVENTA WHERE VENTAID = :id",
        [id_venta]
    )
    detalles = cursor_oracle.fetchall()
    lista_detalles = []
    for d in detalles:
        lista_detalles.append({
            "id_detventa": d[0],
            "cantidad": d[1],
            "preciototal": d[2],
            "celularid": d[3]
        })
    documento = {
        "id_venta": id_venta,
        "fecha": str(v[1]),
        "total": v[2],
        "clienteid": v[3],
        "detalles": lista_detalles
    }
    coleccion_ventas.insert_one(documento)
print(f"✓ {len(ventas)} ventas migradas")

# ==========================================
# CERRAR CONEXIONES
# ==========================================
cursor_oracle.close()
conexion_oracle.close()
cliente_mongo.close()

print("\n✅ MIGRACIÓN COMPLETADA EXITOSAMENTE!")